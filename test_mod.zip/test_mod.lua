local M = {}

function M.info()
   return "this is a test module from physfs"
end

function M.add(a, b)
   return a + b
end

return M
